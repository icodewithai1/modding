# MonkeyClient — Eclipse mod menu template (Meta Quest / Gorilla Tag)

Source template for a **holdable, world-space Quest mod menu** branded **Eclipse**,
matching the patched `libEclipse.so` build (black theme, smaller portrait menu,
highlight-only-when-on buttons) and adding the features that cannot be added by
hex-patching a compiled binary:

| Feature | Where |
|---|---|
| All-black opaque portrait menu (panel 0.0875 × 0.875 × 0.6125 — 12.5 % smaller than the original) | `src/Menu/Theme.h`, `src/Mods/Settings.cpp` (`Settings::Init`) |
| Menu title **Eclipse** | `src/Config.h` (`MENU_NAME`) |
| Buttons highlight **only when toggled on** | `src/Menu/UIButton.cpp` |
| **Rainbow Menu Name** toggle (Settings page) — hue-cycles the menu title | `src/Mods/RainbowMenuName.*` |
| **Drop Menu** toggle (Settings page) — release grip and the menu drops instead of hiding | `src/Menu/MenuManager.cpp` (`Update`) |
| Crash logs exported to **/storage/emulated/0/Download/MonkeyClient/logs/** | `src/Crash/CrashLogger.cpp` |
| Hold-to-open menu (grip), finger-poke buttons with edge-debounce | `src/Menu/MenuManager.cpp` |

## How the menu behaves (as implemented + self-tested)

* Hold **grip** → the menu pins in front of that hand (positioned once on grab,
  so the free hand can reach every button). Release → it hides — or, with
  **Drop Menu** on, it detaches and falls to the ground. Grab it again anywhere
  to re-pin it.
* Closing via **Close Menu** while still holding requires releasing the grip
  before it can re-open (no pop-back).
* Tabs `Main` / `Settings` highlight the active page; toggles highlight only
  while ON; action buttons (Close/Reset) never highlight.
* Crash handler catches SIGSEGV/SIGABRT/SIGBUS/SIGILL/SIGFPE/SIGTRAP and writes
  `crash_<timestamp>.log` (signal, fault address, aarch64 register dump,
  symbolized backtrace, last 128 mod log lines) to the Downloads folder, with
  an internal-storage fallback when the game lacks external-storage access.

## Layout

```
MonkeyClient/
├── CMakeLists.txt            aarch64 Android build (NDK) — no external deps
├── build.sh                  one-command build -> build/libMonkeyClient.so
├── extern/                   optional (only if you add native hooking libs)
├── test/selftest.cpp         host self-test (mock il2cpp backend)
└── src/
    ├── main.cpp              entry point: init, menu spawn, crash handler install, update loop
    ├── Config.h              menu name, sizes, colors, paths, keycodes
    ├── Logging.h             logcat + ring buffer (crash dumps include the last lines)
    ├── Crash/CrashLogger.*   signal handlers -> crash_<date>.log in Downloads
    ├── Menu/Theme.h          the Eclipse theme values (single source of truth)
    ├── Menu/UIButton.*       toggle buttons, highlight only when ON
    ├── Menu/MenuManager.*    holdable menu: title, pages, poke input, drop physics
    ├── Mods/Settings.*       settings state + Init() defaults (match the .so patches)
    ├── Mods/RainbowMenuName.* rainbow title effect
    └── IL2CPP/GameAPI.*      ALL game/il2cpp access, isolated here (public il2cpp C API)
```

## Building

1. Install Android NDK **r25+** and CMake 3.22+.
2. `./build.sh` → `build/libMonkeyClient.so` (no third-party libraries needed).
3. Side-load like any Quest mod (Horizon mod loader / your mod loader of choice).

## Integration checklist

- `src/IL2CPP/GameAPI.cpp` is the **only** file that touches the game. It
  resolves classes/methods through the public il2cpp C exports, so no resolver
  library is needed. Class/field names there (GorillaLocomotion.Player rig
  fields, UI primitives) match the dump layout used by the original client —
  adjust them if your dump differs.
- Controller input uses `UnityEngine.Input.GetKey` with joystick keycodes
  (`Config.h`); swap in a nicer input path there if your loader provides one.
- Crash log path is set in `Config.h` (`DOWNLOAD_LOG_DIR`). If the game has no
  external-storage access, the logger automatically falls back to the app's
  internal files dir and says so in logcat.

## Relation to libEclipse.so

`libEclipse.so` (the hex-patched build of the original client) and this template
agree on the same user-visible settings, expressed in source in
`Mods/Settings.cpp`:

```cpp
backgroundColor = Color(0, 0, 0, 1.0f);          // opaque black  (hex: alpha 0.95 -> 1.0)
menuSize        = Vector3(0.0875f, 0.875f, 0.6125f); // x0.875 smaller, portrait
```

## Self-test (host, no NDK needed)

The menu logic runs on the desktop against a mock il2cpp backend:

```
g++ -std=c++20 -I src -I test/stubs -o /tmp/selftest \
    test/selftest.cpp src/Menu/MenuManager.cpp src/Menu/UIButton.cpp \
    src/Mods/Settings.cpp src/Mods/RainbowMenuName.cpp src/Crash/CrashLogger.cpp
/tmp/selftest
```

It covers: grab/pin, Settings tab, Rainbow Menu Name (toggle + cycling title),
Drop Menu (release → falls, stays visible), page switching, close + close-lock,
and crash-log export (the test actually dereferences NULL in a forked child and
checks the exported log). Note: `test/stubs/android/log.h` is a one-file stand-in
for the Android NDK header; create it if you cloned this template without it.
