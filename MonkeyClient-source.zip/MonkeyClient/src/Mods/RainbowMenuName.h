#pragma once
// Rainbow Menu Name — hue-cycles the menu title color while the toggle is on.
namespace RainbowMenuName {

// Call once per menu frame with the current menu title object.
void Apply(void* textMeshObj);
// Toggle state lives in Settings::rainbowMenuName; this just advances hue.
void Tick();

} // namespace RainbowMenuName
