// Rainbow Menu Name — see RainbowMenuName.h.
#include "RainbowMenuName.h"

#include "Settings.h"
#include "../IL2CPP/GameAPI.h"

namespace RainbowMenuName {

static float s_hue = 0.0f;

void Tick() {
    if (!Settings::rainbowMenuName) return;
    s_hue += 0.01f;              // full cycle every ~100 frames
    if (s_hue >= 1.0f) s_hue -= 1.0f;
}

// HSV -> RGB helper (standard formula), avoids external deps.
static Game::Color Hsv(float h) {
    float i = h * 6.0f;
    int sector = (int)i % 6;
    float f = i - (int)i;
    float q = 1.0f - f;
    switch (sector) {
        case 0: return { 1.0f, f,     0.0f, 1.0f };
        case 1: return { q,    1.0f,  0.0f, 1.0f };
        case 2: return { 0.0f, 1.0f,  f,    1.0f };
        case 3: return { 0.0f, q,     1.0f, 1.0f };
        case 4: return { f,    0.0f,  1.0f, 1.0f };
        default:return { 1.0f,  0.0f,  q,   1.0f };
    }
}

void Apply(void* textMeshObj) {
    if (!textMeshObj) return;
    Game::Color c = Settings::rainbowMenuName ? Hsv(s_hue) : Game::Color{1, 1, 1, 1};
    Game::SetTextColor(textMeshObj, c);
}

} // namespace RainbowMenuName
