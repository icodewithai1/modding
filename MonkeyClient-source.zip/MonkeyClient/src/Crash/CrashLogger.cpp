// Crash logger — see CrashLogger.h.
//
// Design rules that make it actually work:
//   * The handler is async-signal-safe: NO fopen/fprintf/malloc/new. It uses
//     only open(2)/write(2)/close(2)/fsync(2) and hand-rolled formatting, so
//     it still runs when the crash itself happened inside malloc, stdio or
//     the C++ runtime (the most common crash cases).
//   * SA_ONSTACK is backed by a real sigaltstack, so stack-overflow SIGSEGVs
//     are handled too.
//   * Candidate log dirs are prepared at Install() (dirs pre-created, paths
//     pre-computed); at crash time the handler only open()s the first one
//     that works, trying the next on failure.
//   * The backtrace is a raw frame-pointer walk started from the faulting
//     context's FP (x29 / rbp) — no backtrace(), no dladdr inside the
//     handler. The mod's own load base is resolved once in Install().
//   * Critical info (signal, fault address, registers) is written and fsync'd
//     BEFORE the riskier backtrace/recent-log sections.
#include "CrashLogger.h"

#include <android/log.h>
#include <csignal>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <dlfcn.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <ucontext.h>
#include <unistd.h>

#include "../Config.h"
#include "../Logging.h"

namespace CrashLogger {

// ----------------------------------------------------------- candidate dirs
// Fixed-size, computed once in Install() so the handler never formats paths.
static char g_dirs[6][160];
static int  g_dirCount = 0;

static char g_selfName[64]  = "unknown";   // e.g. libEclipse.so
static uintptr_t g_selfBase = 0;           // load base of this .so

static volatile sig_atomic_t g_inHandler = 0;   // nested-fault guard
static char g_fallbackDir[160] = "";            // SetFallbackDir override

struct SigDesc { int sig; const char* name; };
static const SigDesc kSignals[] = {
    { SIGSEGV, "SIGSEGV" }, { SIGBUS, "SIGBUS" },   { SIGABRT, "SIGABRT" },
    { SIGILL,  "SIGILL"  }, { SIGFPE, "SIGFPE" },   { SIGTRAP, "SIGTRAP" },
};

// --------------------------------------------------- async-signal-safe I/O
static void W(int fd, const char* s, size_t n) {
    while (n) {
        ssize_t r = write(fd, s, n);
        if (r <= 0) return;          // give up on error; never loop forever
        s += r; n -= (size_t)r;
    }
}
static void WS(int fd, const char* s) { W(fd, s, strlen(s)); }

// Unsigned decimal / hex into a stack buffer, then written.
static void WU(int fd, unsigned long long v) {
    char b[24]; int i = 23; b[23] = '\0';
    do { b[--i] = char('0' + v % 10); v /= 10; } while (v);
    W(fd, b + i, 23 - i);
}
static void WX(int fd, unsigned long long v) {
    char b[20]; int i = 19; b[19] = '\0';
    const char* d = "0123456789abcdef";
    do { b[--i] = d[v & 15]; v >>= 4; } while (v);
    WS(fd, "0x"); W(fd, b + i, 19 - i);
}
static void WI(int fd, long long v) {
    if (v < 0) { WS(fd, "-"); v = -v; }
    WU(fd, (unsigned long long)v);
}

// --------------------------------------------------- signal-safe timestamp
// civil_from_days (Howard Hinnant's algorithm) — no localtime_r (locale locks).
static void FormatStamp(char* out, size_t outLen) {
    struct timespec ts{};
    clock_gettime(CLOCK_REALTIME, &ts);
    long long secs = (long long)ts.tv_sec;
    long long days = secs / 86400;
    long long rem  = secs % 86400; if (rem < 0) { rem += 86400; --days; }
    days += 719468;                                   // shift to civil epoch
    long long era = (days >= 0 ? days : days - 146096) / 146097;
    long long doe = days - era * 146097;
    long long yoe = (doe - doe/1460 + doe/36524 - doe/146096) / 365;
    long long y   = yoe + era * 400;
    long long doy = doe - (365*yoe + yoe/4 - yoe/100);
    long long mp  = (5*doy + 2)/153;
    long long d   = doy - (153*mp+2)/5 + 1;
    long long m   = mp + (mp < 10 ? 3 : -9);
    y += (m <= 2);
    unsigned hh = (unsigned)(rem / 3600), mm = (unsigned)((rem / 60) % 60),
             ss = (unsigned)(rem % 60);
    snprintf(out, outLen, "crash_%04lld%02lld%02lld_%02u%02u%02u.log",
             y, m, d, hh, mm, ss);
}

// ------------------------------------------------------------ dir helpers
// mkdir -p (called at Install() and when re-checking candidates; both are
// outside the faulting path — mkdir() itself is not in the handler's fast path).
static void MkDirChain(const char* path) {
    char buf[160];
    snprintf(buf, sizeof(buf), "%s", path);
    for (char* p = buf + 1; *p; ++p) {
        if (*p == '/') {
            *p = '\0';
            mkdir(buf, 0755);        // EEXIST is fine
            *p = '/';
        }
    }
    mkdir(buf, 0755);
}

// /proc/self/cmdline -> package name; derive the app's own writable dirs.
// Called at Install() (not in the handler).
static void DeriveAppDirs() {
    // 1 + 2: the public Downloads folder (works when the game has legacy
    // external storage — the case on most Quest loader setups).
    snprintf(g_dirs[g_dirCount++], 160, "%s", DOWNLOAD_LOG_DIR);
    snprintf(g_dirs[g_dirCount++], 160, "%s", DOWNLOAD_LOG_DIR_ALT);

    char pkg[128] = "";
    int fd = open("/proc/self/cmdline", O_RDONLY);
    if (fd >= 0) {
        char raw[128] = "";
        ssize_t n = read(fd, raw, sizeof(raw) - 1);
        close(fd);
        if (n > 0) {
            raw[n] = '\0';
            snprintf(pkg, sizeof(pkg), "%s", raw);   // first NUL-terminated arg
            for (char* c = pkg; *c; ++c) if (*c < 32 || *c > 126) { *c = '\0'; break; }
        }
    }
    if (pkg[0]) {
        // The app's own external + internal files dirs are always writable
        // by the app (no storage permission needed).
        snprintf(g_dirs[g_dirCount++], 160,
                 "/storage/emulated/0/Android/data/%s/files/MonkeyClient/logs", pkg);
        snprintf(g_dirs[g_dirCount++], 160,
                 "/data/data/%s/files/MonkeyClient/logs", pkg);
        snprintf(g_dirs[g_dirCount++], 160,
                 "/data/user/0/%s/files/MonkeyClient/logs", pkg);
    }
    if (g_fallbackDir[0])
        snprintf(g_dirs[g_dirCount++], 160, "%s", g_fallbackDir);
}

static void ResolveSelf() {
    Dl_info info{};
    if (dladdr((void*)&ResolveSelf, &info) && info.dli_fname) {
        g_selfBase = (uintptr_t)info.dli_fbase;
        const char* slash = strrchr(info.dli_fname, '/');
        snprintf(g_selfName, sizeof(g_selfName), "%s", slash ? slash + 1 : info.dli_fname);
    }
}

// --------------------------------------------------------------- formatting
#define LINE(...) do { WS(fd, __VA_ARGS__); } while (0)

static void DumpRegisters(int fd, ucontext_t* uc) {
#if defined(__aarch64__)
    const mcontext_t& mc = uc->uc_mcontext;
    LINE("registers (aarch64):\n");
    for (int i = 0; i < 31; ++i) {
        char b[32]; snprintf(b, sizeof(b), "  x%-2d = ", i); WS(fd, b);
        WX(fd, (unsigned long long)mc.regs[i]);
        WS(fd, (i % 4 == 3) ? "\n" : "");
    }
    LINE("  pc  = "); WX(fd, (unsigned long long)mc.pc);     WS(fd, "\n");
    LINE("  sp  = "); WX(fd, (unsigned long long)mc.sp);     WS(fd, "\n");
    LINE("  fp  = "); WX(fd, (unsigned long long)mc.regs[29]); WS(fd, "\n");
    LINE("  lr  = "); WX(fd, (unsigned long long)mc.regs[30]); WS(fd, "\n");
#elif defined(__x86_64__)
    const mcontext_t& mc = uc->uc_mcontext;
    LINE("registers (x86_64):\n");
    static const char* names[] = {
        "r8", "r9", "r10", "r11", "r12", "r13", "r14", "r15",
        "rdi", "rsi", "rbp", "rbx", "rdx", "rax", "rcx", "rsp", "rip" };
    for (int i = REG_R8; i <= REG_RIP; ++i) {
        char b[32]; snprintf(b, sizeof(b), "  %-4s= ", names[i - REG_R8]); WS(fd, b);
        WX(fd, (unsigned long long)mc.gregs[i]);
        WS(fd, (i % 4 == 3) ? "\n" : "");
    }
    LINE("\n");
#else
    (void)uc; LINE("registers: unsupported arch\n");
#endif
}

// Frame-pointer walk from the faulting context — no malloc, no dladdr.
// Frames of this .so are shown as "libEclipse.so+0xOFFSET" (base resolved at
// Install()); everything else prints the raw PC.
static void PrintBacktrace(int fd, ucontext_t* uc) {
    LINE("backtrace (frame-pointer walk):\n");
#if defined(__aarch64__)
    uintptr_t fp = (uintptr_t)uc->uc_mcontext.regs[29];
    uintptr_t pc = (uintptr_t)uc->uc_mcontext.pc;
#elif defined(__x86_64__)
    uintptr_t fp = (uintptr_t)uc->uc_mcontext.gregs[REG_RBP];
    uintptr_t pc = (uintptr_t)uc->uc_mcontext.gregs[REG_RIP];
#else
    uintptr_t fp = 0, pc = 0;
#endif
    if (pc) {
        LINE("  #00 pc "); WX(fd, pc);
        if (g_selfBase && pc >= g_selfBase && pc - g_selfBase < 0x10000000) {
            LINE("  "); WS(fd, g_selfName); LINE("+"); WX(fd, pc - g_selfBase);
        }
        WS(fd, "\n");
    }
    for (int i = 1; i < 64 && fp; ++i) {
        // sanity: aligned, plausible userspace, chain monotonic-ish
        if (fp < 0x1000 || (fp & 7)) break;
        uintptr_t next = *(uintptr_t*)fp;
        uintptr_t lr   = *(uintptr_t*)(fp + 8);
        LINE("  #"); WU(fd, (unsigned)i); LINE(" pc "); WX(fd, lr);
        if (g_selfBase && lr >= g_selfBase && lr - g_selfBase < 0x10000000) {
            LINE("  "); WS(fd, g_selfName); LINE("+"); WX(fd, lr - g_selfBase);
        }
        WS(fd, "\n");
        if (next <= fp || next - fp > 0x100000) break;   // bad chain -> stop
        fp = next;
    }
}

static void DumpRecentLogs(int fd) {
    LINE("recent mod log lines:\n");
    MonkeyLog::ForEachRecentLine([&](const MonkeyLog::Line& line) {
        LINE("  "); WI(fd, line.ms); LINE(" "); WS(fd, line.text); WS(fd, "\n");
    });
}

#undef LINE

// ---------------------------------------------------------------- handler
static void FaultHandler(int sig, siginfo_t* info, void* ctx) {
    if (g_inHandler) _exit(127);
    g_inHandler = 1;

    // 1) pick the first writable log file (candidates were prepared at
    //    Install(); mkdir is retried here only as a last resort).
    char name[64];
    FormatStamp(name, sizeof(name));
    int fd = -1;
    char usedPath[288] = "";
    for (int i = 0; i < g_dirCount && fd < 0; ++i) {
        snprintf(usedPath, sizeof(usedPath), "%s/%s", g_dirs[i], name);
        fd = open(usedPath, O_WRONLY | O_CREAT | O_TRUNC, 0644);
        if (fd < 0) { MkDirChain(g_dirs[i]);                    // retry once
                      fd = open(usedPath, O_WRONLY | O_CREAT | O_TRUNC, 0644); }
    }

    if (fd >= 0) {
        const char* sigName = "?";
        for (const auto& d : kSignals) if (d.sig == sig) sigName = d.name;

        WS(fd, MENU_NAME " v" MENU_VERSION " crash log — "); WS(fd, name); WS(fd, "\n");
        WS(fd, "signal: "); WS(fd, sigName); WS(fd, " ("); WI(fd, sig); WS(fd, ")\n");
        WS(fd, "module: "); WS(fd, g_selfName);
        WS(fd, " base "); WX(fd, (unsigned long long)g_selfBase); WS(fd, "\n");
        WS(fd, "tid: "); WU(fd, (unsigned long long)syscall(SYS_gettid)); WS(fd, "\n");
        if (info) {
            WS(fd, "fault address: "); WX(fd, (unsigned long long)(uintptr_t)info->si_addr);
            WS(fd, " (si_code "); WI(fd, info->si_code); WS(fd, ")\n");
        }
        if (ctx) DumpRegisters(fd, (ucontext_t*)ctx);
        WS(fd, "\n");
        fsync(fd);                          // critical info is on disk now

        if (ctx) PrintBacktrace(fd, (ucontext_t*)ctx);
        WS(fd, "\n");
        DumpRecentLogs(fd);
        WS(fd, "\nlog written to: "); WS(fd, usedPath); WS(fd, "\n");
        fsync(fd);
        close(fd);
        __android_log_print(ANDROID_LOG_ERROR, ANDROID_LOG_TAG,
                            "crash (signal %d) captured — log: %s", sig, usedPath);
    } else {
        __android_log_print(ANDROID_LOG_ERROR, ANDROID_LOG_TAG,
                            "crash (signal %d) captured — could not open any "
                            "log dir (see CrashLogger dirs in logcat)", sig);
    }

    // Chain to the default disposition so the OS still treats it as a crash.
    // The handler runs with ALL signals blocked (sigfillset at Install()), so
    // unblock before re-raising or the process would just exit normally.
    struct sigaction sa{};
    sa.sa_handler = SIG_DFL;
    sigemptyset(&sa.sa_mask);
    sigaction(sig, &sa, nullptr);
    sigset_t empty;
    sigemptyset(&empty);
    sigprocmask(SIG_SETMASK, &empty, nullptr);
    raise(sig);
    _exit(127);
}

// ------------------------------------------------------------- public API
void SetFallbackDir(const char* dir) {
    snprintf(g_fallbackDir, sizeof(g_fallbackDir), "%s",
             dir ? dir : "");
}

void Install() {
    ResolveSelf();
    DeriveAppDirs();

    // Back the SA_ONSTACK flag with a real alternate stack — without it,
    // stack-overflow SIGSEGVs would run the handler on the broken stack and
    // crash the handler itself. (Per-thread: installed on the thread that
    // calls Install(); crashes on other threads still handled, just without
    // the altstack protection. Fixed size: SIGSTKSZ is not a compile-time
    // constant on newer glibc.)
    static char altStack[128 * 1024];
    stack_t ss{};
    ss.ss_sp = altStack;
    ss.ss_size = sizeof(altStack);
    ss.ss_flags = 0;
    sigaltstack(&ss, nullptr);

    struct sigaction sa{};
    sa.sa_sigaction = FaultHandler;
    sa.sa_flags = SA_SIGINFO | SA_ONSTACK;
    sigfillset(&sa.sa_mask);
    for (const auto& d : kSignals) sigaction(d.sig, &sa, nullptr);

    // Pre-create the candidate dirs so a crash only needs one open().
    for (int i = 0; i < g_dirCount; ++i) MkDirChain(g_dirs[i]);

    // abort() raises SIGABRT, so asserts / runtime aborts are covered by the
    // same handler — no libc hooking needed.
    MonkeyLog::Print("CrashLogger installed (%d candidate dirs, first: %s)",
                     g_dirCount, g_dirCount ? g_dirs[0] : "(none)");
}

} // namespace CrashLogger
