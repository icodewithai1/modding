// Crash logger — writes crash_<timestamp>.log with signal info, register dump,
// a symbolized backtrace and the mod's recent log lines to a folder in
// Downloads. See CrashLogger.h.
#include "CrashLogger.h"

#include <android/log.h>
#include <csignal>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <ctime>
#include <dlfcn.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <execinfo.h>

#include "../Config.h"
#include "../Logging.h"

namespace CrashLogger {

static char g_fallback_dir[192] = "/data/local/tmp";

// Which fault we are currently handling (nested-signal guard).
static volatile sig_atomic_t g_in_handler = 0;

struct SigDesc { int sig; const char* name; };
static const SigDesc kSignals[] = {
    { SIGSEGV, "SIGSEGV" }, { SIGBUS, "SIGBUS" }, { SIGABRT, "SIGABRT" },
    { SIGILL, "SIGILL" },   { SIGFPE, "SIGFPE" }, { SIGTRAP, "SIGTRAP" },
};

// --------------------------------------------------------------- file helpers
static FILE* OpenCrashFile(char* out_path, size_t out_len) {
    time_t t = time(nullptr);
    tm tmv{};
    localtime_r(&t, &tmv);
    char name[64];
    strftime(name, sizeof(name), "crash_%Y%m%d_%H%M%S.log", &tmv);

    const char* dirs[] = { DOWNLOAD_LOG_DIR, DOWNLOAD_LOG_DIR_ALT, g_fallback_dir };
    for (const char* dir : dirs) {
        if (!dir || !*dir) continue;
        mkdir(dir, 0755); // logs dir
        snprintf(out_path, out_len, "%s/%s", dir, name);
        FILE* f = fopen(out_path, "w");
        if (f) {
            fprintf(f, "MonkeyClient crash log — %s\n", name);
            fprintf(f, "menu: %s v%s\n\n", MENU_NAME, MENU_VERSION);
            return f;
        }
    }
    return nullptr;
}

// --------------------------------------------------------------- formatting
static void DumpRegisters(FILE* f, ucontext_t* uc) {
#if defined(__aarch64__)
    const mcontext_t& mc = uc->uc_mcontext;
    fprintf(f, "registers (aarch64):\n");
    for (int i = 0; i < 31; ++i) {
        fprintf(f, "  x%-2d = 0x%016llx%s", i, (unsigned long long)mc.regs[i],
                (i % 4 == 3) ? "\n" : "");
    }
    fprintf(f, "  pc  = 0x%016llx\n", (unsigned long long)mc.pc);
    fprintf(f, "  sp  = 0x%016llx\n", (unsigned long long)mc.sp);
#else
    (void)f; (void)uc;
    fprintf(f, "registers: unsupported arch\n");
#endif
}

static void PrintBacktrace(FILE* f) {
    void* frames[64];
    int n = backtrace(frames, 64);
    fprintf(f, "backtrace (%d frames):\n", n);
    for (int i = 0; i < n; ++i) {
        Dl_info info{};
        if (dladdr(frames[i], &info) && info.dli_fname) {
            uintptr_t off = (uintptr_t)frames[i] - (uintptr_t)info.dli_fbase;
            fprintf(f, "  #%-2d %s + 0x%lx  (%s)\n", i,
                    info.dli_sname ? info.dli_sname : "??", (unsigned long)off,
                    info.dli_fname);
        } else {
            fprintf(f, "  #%-2d %p\n", i, frames[i]);
        }
    }
}

static void DumpRecentLogs(FILE* f) {
    fprintf(f, "recent mod log lines:\n");
    MonkeyLog::ForEachRecentLine([&](const MonkeyLog::Line& line) {
        fprintf(f, "  %lld %s\n", line.ms, line.text);
    });
}

// --------------------------------------------------------------- handler
static void FaultHandler(int sig, siginfo_t* info, void* ctx) {
    if (g_in_handler) { _exit(127); }
    g_in_handler = 1;

    char path[512];
    FILE* f = OpenCrashFile(path, sizeof(path));
    if (f) {
        const char* name = "?";
        for (const auto& d : kSignals) if (d.sig == sig) name = d.name;
        fprintf(f, "signal: %s (%d)\n", name, sig);
        if (info) fprintf(f, "fault address: %p (code %d)\n", info->si_addr, info->si_code);
        if (ctx) DumpRegisters(f, (ucontext_t*)ctx);
        fprintf(f, "\n");
        PrintBacktrace(f);
        fprintf(f, "\n");
        DumpRecentLogs(f);
        fprintf(f, "\nlog written to: %s\n", path);
        fclose(f);
    }
    // Keep logcat informed even if the file could not be opened.
    __android_log_print(ANDROID_LOG_ERROR, ANDROID_LOG_TAG,
                        "crash (signal %d) captured; log file: %s", sig,
                        f ? path : "<unavailable>");

    // Chain to the default disposition so the OS still treats it as a crash.
    // NOTE: the handler runs with ALL signals blocked (sigfillset above), so
    // the fault signal must be unblocked before re-raising, or it would stay
    // pending and the process would exit normally instead of crashing.
    struct sigaction sa{};
    sa.sa_handler = SIG_DFL;
    sigemptyset(&sa.sa_mask);
    sigaction(sig, &sa, nullptr);
    sigset_t empty;
    sigemptyset(&empty);
    sigprocmask(SIG_SETMASK, &empty, nullptr);
    raise(sig);
    _exit(127);
}

// abort() raises SIGABRT, which the FaultHandler catches — no separate hook needed.

// --------------------------------------------------------------- public API
void SetFallbackDir(const char* dir) {
    snprintf(g_fallback_dir, sizeof(g_fallback_dir), "%s", dir ? dir : "/data/local/tmp");
}

void Install() {
    struct sigaction sa{};
    sa.sa_sigaction = FaultHandler;
    sa.sa_flags = SA_SIGINFO | SA_ONSTACK;
    sigfillset(&sa.sa_mask);
    for (const auto& d : kSignals) sigaction(d.sig, &sa, nullptr);
    // abort() raises SIGABRT, so asserts / runtime aborts are covered by the
    // same handler — no libc hooking needed.
    MonkeyLog::Print("CrashLogger installed -> %s", DOWNLOAD_LOG_DIR);
}

} // namespace CrashLogger
