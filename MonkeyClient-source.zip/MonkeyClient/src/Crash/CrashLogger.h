#pragma once
// Crash logger: exports mod + native crash logs to a folder in Downloads
// when the target app crashes (SIGSEGV/SIGABRT/SIGBUS/SIGILL/SIGFPE/SIGTRAP).
//
// Output: /storage/emulated/0/Download/MonkeyClient/logs/crash_YYYYmmdd_HHMMSS.log
// (falls back to the app's internal files dir if external storage is not writable)

namespace CrashLogger {

// Install signal handlers + an abort() hook. Call once during mod init.
void Install();

// Set the internal-storage fallback directory (app files dir), used when
// /storage/emulated/0/Download is not writable from inside the game process.
void SetFallbackDir(const char* dir);

} // namespace CrashLogger
