#pragma once
// Crash logger: exports mod + native crash logs to a folder in Downloads
// when the target app crashes (SIGSEGV/SIGABRT/SIGBUS/SIGILL/SIGFPE/SIGTRAP).
//
// Output: /storage/emulated/0/Download/MonkeyClient/logs/crash_YYYYmmdd_HHMMSS.log
// Candidate dirs are tried in order until one opens:
//   1. DOWNLOAD_LOG_DIR            (public Downloads)
//   2. DOWNLOAD_LOG_DIR_ALT        (/sdcard mount)
//   3. /storage/emulated/0/Android/data/<pkg>/files/MonkeyClient/logs
//   4. /data/data/<pkg>/files/MonkeyClient/logs        (always writable)
//   5. /data/user/0/<pkg>/files/MonkeyClient/logs      (same inode as 4)
//   6. the SetFallbackDir() override, if one was given
// <pkg> is read from /proc/self/cmdline at Install(); dirs 1-6 are pre-created
// at Install() so the handler only needs one open() at crash time.
//
// The handler is async-signal-safe (open/write/fsync only — no stdio, no
// malloc), backed by a sigaltstack for stack-overflow SIGSEGVs, and re-raises
// the signal so the OS still reports the crash normally.

namespace CrashLogger {

// Install signal handlers + sigaltstack + pre-create the log dirs.
// Call once during mod init, on the thread that stays alive.
void Install();

// Optional explicit last-resort directory (e.g. getFilesDir() passed through
// JNI). Call BEFORE Install(); pass nullptr to clear.
void SetFallbackDir(const char* dir);

} // namespace CrashLogger
